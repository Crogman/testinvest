tinyMCE.init({
		mode : "textareas",
		theme : "advanced",
		force_br_newlines : true,
   		force_p_newlines : false,
   		plugins: "table, template",
   		theme_advanced_buttons3_add : "tablecontrols",
   		table_inline_editing : true,
   		keep_styles : false,
		cleanup : false
	});