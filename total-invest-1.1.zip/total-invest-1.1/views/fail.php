<h3>Deposit transaction error</h3>
<p class="error"><strong>Alert:</strong> Your deposit transaction has been failed! Please try again later.</p>
<p>Go to your <a href="member.php">member account &raquo;</a></p>