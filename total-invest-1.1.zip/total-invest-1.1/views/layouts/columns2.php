<style>
	#content {
		width: 800px;
	}
</style>
<div id="sidebar"><?php echo $controller->menu ?></div>
<div id="content"><?php echo $content ?></div>