<div id="content">
	<?php echo $content ?>
</div>