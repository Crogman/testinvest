<h3><?php echo $page->name ?></h3>
<?php echo $page->content ?>